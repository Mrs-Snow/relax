import javax.sound.sampled.*;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/**
 * @Class: soundController
 * @Author: MrSnow
 * @Date: 2022/6/5 14:34
 */
public class SoundController {
    private Clip clip ;

    public SoundController() {
        try {
            URL url = SoundController.class.getClassLoader().getResource("11211.wav");
            AudioInputStream hit = AudioSystem.getAudioInputStream(url);
            clip = AudioSystem.getClip();
            clip.open(hit);
        } catch (UnsupportedAudioFileException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    public void play(){
        if (clip.isRunning()){
            clip.stop();
        }
        clip.setFramePosition(0);
        clip.start();
    }
}
