import javax.swing.*;

/**
 * @Class: Nail
 * @Author: MrSnow
 * @Date: 2022/6/5 13:04
 */
public class Nail extends Thread{
    public static Integer biteNail = 0 ;
    public  static Integer Laodong = 0 ;
    SoundController sdc ;

    public void strike(){
        while (Laodong>0){
            System.out.println("老董生气了，怒气值： "+Laodong);
            this.sdc.play();
            JOptionPane.showMessageDialog(null,"打洗你！让你啃指甲！！啪啪啪啪啪啪！","不准啃指甲！",JOptionPane.ERROR_MESSAGE);
            Laodong-=1;
        }
        NoNailBiting.sorry();
        //防止不停执行strike，此时挨打取决于老董的怒气
        biteNail = 0 ;
    }

    @Override
    public void run() {
        System.out.println("监控啃指甲的摄像头已启动！");
        while (true){
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (biteNail == 1 ) {
                strike();
            }
        }
    }

    public void setSdc(SoundController sdc) {
        this.sdc = sdc;
    }
}
