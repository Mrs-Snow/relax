import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @Class: NoNailBiting
 * @Author: MrSnow
 * @Date: 2022/6/5 13:09
 */
public class NoNailBiting {

    public static void main(String[] args) {
        Nail nail = new Nail();
        nail.start();
        SoundController soundController = new SoundController();
        nail.setSdc(soundController);
        bite();
    }

    public static void bite(){
        //窗体
        JFrame frame = new JFrame();
        frame.setTitle("啃指甲会有什么后果");
        frame.setSize(300,100);
        frame.setDefaultCloseOperation(3);
        frame.setLocationRelativeTo(null);
        //流式布局
        FlowLayout flowLayout = new FlowLayout();
        frame.setLayout(flowLayout);
        //按钮
        JButton bite = new JButton("我要啃指甲！");
        frame.add(bite);
        bite.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Nail.biteNail = 1 ;
                Nail.Laodong = 10 ;
            }
        });
        frame.setVisible(true);
    }

    public static void sorry(){
        //窗体
        JFrame frame = new JFrame();
        frame.setTitle("错了吗？");
        frame.setSize(300,100);
        frame.setDefaultCloseOperation(3);
        frame.setLocationRelativeTo(null);

        //流式布局
        FlowLayout flowLayout = new FlowLayout();
        frame.setLayout(flowLayout);

        //不知悔改
        JButton yes = new JButton("错了，下次还敢~");
        yes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"不知悔改是吧？","什么！",JOptionPane.QUESTION_MESSAGE);
                Nail.Laodong += 10 ;
                Nail.biteNail = 1 ;
            }
        });

        //积极认错
        JButton no = new JButton("错啦~太也不敢啦！");
        no.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"啃指甲不利于身体健康，大家都不要再啃指甲了噢~","真棒！",JOptionPane.QUESTION_MESSAGE);
                Nail.Laodong = 0 ;
                Nail.biteNail = 0 ;
                System.exit(-1);
            }
        });

        frame.add(yes);
        frame.add(no);

        frame.setVisible(true);

    }
}
